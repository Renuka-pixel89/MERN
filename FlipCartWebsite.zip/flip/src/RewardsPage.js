//RewardsPage.js
import React from 'react';
import { Container, Row, Col, Table, Card, Button } from 'react-bootstrap';


function RewardsPage() {
  const rewards = [
    { id: 1, name: 'Reward 1', description: 'Description of Reward 1', points: 100 },
    { id: 2, name: 'Reward 2', description: 'Description of Reward 2', points: 200 },
    { id: 3, name: 'Reward 3', description: 'Description of Reward 3', points: 300 },
  ];

  return (
    <Container className="rewards-page">
      <Row>
        <Col md={12} className="text-center">
          <h1>Rewards Program</h1>
          <p>Earn points and Regain them for exciting rewards!</p>
        </Col>
      </Row>

      <Row className="mt-4">
        {rewards.map(reward => (
          <Col md={4} key={reward.id} className="mb-4">
            <Card>
              <Card.Body>
                <Card.Title>{reward.name}</Card.Title>
                <Card.Text>
                  {reward.description}
                </Card.Text>
                <Card.Text>
                  <strong>Points Required: {reward.points}</strong>
                </Card.Text>
                <Button variant="primary">Regain</Button>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      <Row className="mt-4">
        <Col md={12}>
          <h2>My Rewards History</h2>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Points Used</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {/* This would be dynamically populated in a real application */}
              <tr>
                <td>1</td>
                <td>Reward 1</td>
                <td>Description of Reward 1</td>
                <td>100</td>
                <td>2024-08-22</td>
              </tr>
              <tr>
                <td>2</td>
                <td>Reward 2</td>
                <td>Description of Reward 2</td>
                <td>200</td>
                <td>2024-08-21</td>
              </tr>
            </tbody>
          </Table>
        </Col>
      </Row>
    </Container>
  );
}

export default RewardsPage;
