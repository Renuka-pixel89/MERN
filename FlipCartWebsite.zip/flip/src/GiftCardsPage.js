//GiftCardsPage.js
import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Form } from 'react-bootstrap';


function GiftCardsPage() {
  const [amount, setAmount] = useState('');

  const giftCards = [
    { id: 1, amount: 50, description: 'Gift card worth $50' },
    { id: 2, amount: 100, description: 'Gift card worth $100' },
    { id: 3, amount: 200, description: 'Gift card worth $200' },
  ];

  const handleAmountChange = (e) => {
    setAmount(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Purchased a gift card worth $${amount}`);
  };

  return (
    <Container className="gift-cards-page">
      <Row>
        <Col md={12} className="text-center">
          <h1>Gift Cards</h1>
          <p>Purchase gift cards for yourself or as a gift for someone special!</p>
        </Col>
      </Row>

      <Row className="mt-4">
        {giftCards.map(card => (
          <Col md={4} key={card.id} className="mb-4">
            <Card>
              <Card.Body>
                <Card.Title>${card.amount}</Card.Title>
                <Card.Text>{card.description}</Card.Text>
                <Button variant="primary">Buy Now</Button>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      <Row className="mt-4">
        <Col md={12}>
          <h2>Purchase Gift Card</h2>
          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formAmount">
              <Form.Label>Select Amount</Form.Label>
              <Form.Control
                type="number"
                placeholder="Enter amount"
                value={amount}
                onChange={handleAmountChange}
              />
            </Form.Group>
            <Button variant="primary" type="submit" className="mt-3">
              Purchase
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default GiftCardsPage;
