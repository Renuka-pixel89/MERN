//OrdersPage.js
import React, { useState, useEffect } from 'react';
import { Container, Table } from 'react-bootstrap';

function OrdersPage() {

  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchedOrders = [
      { id: 1, productName: 'Rice', quantity: 2, totalPrice: 400 },
      { id: 2, productName: 'Pulses', quantity: 1, totalPrice: 150 },
      { id: 3, productName: 'Vegetables', quantity: 3, totalPrice: 300 },
    ];
    setOrders(fetchedOrders);
  }, []);

  return (
    <Container>
      <h2 className="mt-4">Your Orders</h2>
      <Table striped bordered hover className="mt-4">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Total Price</th>
          </tr>
        </thead>
        <tbody>
          {orders.length === 0 ? (
            <tr>
              <td colSpan="4" className="text-center">No orders found.</td>
            </tr>
          ) : (
            orders.map(order => (
              <tr key={order.id}>
                <td>{order.id}</td>
                <td>{order.productName}</td>
                <td>{order.quantity}</td>
                <td>${order.totalPrice.toFixed(2)}</td>
              </tr>
            ))
          )}
        </tbody>
      </Table>
    </Container>
  );
}

export default OrdersPage;
