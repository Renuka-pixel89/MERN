/*import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;*/

//App.js
import React, { useState } from 'react';
import { Container, Row, Col, Form, Dropdown, Button } from 'react-bootstrap';
import './index.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FaUser, FaShoppingCart, FaHandHoldingUsd } from 'react-icons/fa';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './HomePage';
import SignUpPage from './SignUpPage';
import ProfilePage from './ProfilePage';
import OrdersPage from './OrdersPage';
import RewardsPage from './RewardsPage';
import GiftCardsPage from './GiftCardsPage';
import SearchResultsPage from './SearchResultsPage';

function App() {
  const [cart, setCart] = useState([]);

  const handleBuyNow = (item) => {
    setCart(prevCart => [...prevCart, item]);
  };

  return (
    <Router>
      <Container id="renu">
        <Row>
          <Col md={2}>
            <a href="/" className="logo-link">
              <img src="https://static-assets-web.flixcart.com/batman-returns/batman-returns/p/images/fkheaderlogo_exploreplus-44005d.svg" alt="logo" />
            </a>
          </Col>
          <Col md={4} id="r1">
            <Form>
              <Form.Group controlId="searchBar">
                <Form.Control
                  type="text"
                  placeholder="Search for Products, Brands and More"
                />
              </Form.Group>
            </Form>
          </Col>
          <Col md={2}>
            <Dropdown>
              <Dropdown.Toggle variant="outline-secondary" id="dropdown-basic" className="login-btn">
                <FaUser /> Login
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item href="/signup">Sign Up</Dropdown.Item>
                <Dropdown.Item href="/profile">My Profile</Dropdown.Item>
                <Dropdown.Item href="/orders">Orders</Dropdown.Item>
                <Dropdown.Item href="/rewards">Rewards</Dropdown.Item>
                <Dropdown.Item href="/giftcards">Gift Cards</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </Col>
          <Col md={2}>
            <Button variant="outline-secondary" className="cart-btn">
              <FaShoppingCart /> Cart ({cart.length})
            </Button>
          </Col>
          <Col md={2}>
            <Button variant="outline-secondary" className="cart-btn1">
              <FaHandHoldingUsd /> Become a Seller
            </Button>
          </Col>
        </Row>

        <div className="main-content">
          <Routes>
            <Route path="/" element={<HomePage handleBuyNow={handleBuyNow} />} />
            <Route path="/signup" element={<SignUpPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/orders" element={<OrdersPage />} />
            <Route path="/rewards" element={<RewardsPage />} />
            <Route path="/giftcards" element={<GiftCardsPage />} />
            <Route path="/search" element={<SearchResultsPage />} />
          </Routes>
        </div>

        <Row className="mt-4">
          <Col md={12} className="text-center">
            <h3>Cart Items</h3>
            {cart.length === 0 ? (
              <p>No items in the cart.</p>
            ) : (
              <ul>
                {cart.map((item, index) => (
                  <li key={index}>{item.name}</li>
                ))}
              </ul>
            )}
          </Col>
        </Row>
      </Container>
    </Router>
  );
}

export default App;
