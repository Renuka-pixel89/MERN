//HomePage.js
import React, { useState } from 'react';
import { Container, Row, Col, Carousel, Button } from 'react-bootstrap';
import './index.css';

function HomePage({ handleBuyNow }) {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);

  const groceryItems = [
    { id: 1, name: 'Rice', image: 'https://tse4.mm.bing.net/th?id=OIP.xgyYtRaT_jlZRqjHzp1ZSQHaHa&pid=Api&P=0&h=80' },
    { id: 2, name: 'Pulses', image: 'https://tse2.mm.bing.net/th?id=OIP.kHm7UNdU63IQf0wg4Y4JKQHaHa&pid=Api&P=0&h=80' },
    { id: 3, name: 'Vegetables', image: 'https://tse2.mm.bing.net/th?id=OIP.Py4eRbJ0WIFjs51eUrIErAHaEo&pid=Api&P=0&h=80' },
    { id: 4, name: 'Fruits', image: 'https://tse3.mm.bing.net/th?id=OIP.168VYOAiZy36geyQv02a1QHaE8&pid=Api&P=0&h=80' },
    { id: 5, name: 'Tea Powder', image: 'https://tse3.mm.bing.net/th?id=OIP.a7AlTO9gF7CfLtvsqfAaAQHaHa&pid=Api&P=0&h=80' },
    { id: 6, name: 'Grains', image: 'https://tse3.mm.bing.net/th?id=OIP.ZgMFsNffo06cPLw5gaXbAwHaE9&pid=Api&P=0&h=80' },
    { id: 7, name: 'Condiments', image: 'https://tse3.mm.bing.net/th?id=OIP.R7huqtCgQYd41Inj53C1jAHaHU&pid=Api&P=0&h=80' },
    { id: 8, name: 'Meat', image: 'https://tse4.mm.bing.net/th?id=OIP.yAqozRkI7XYPdGk2qtjZhwHaFP&pid=Api&P=0&h=80' },
    { id: 9, name: 'Snacks', image: 'https://tse2.mm.bing.net/th?id=OIP.7Au8sSgD3sKhERqekJXWVgHaE6&pid=Api&P=0&h=80' },
    { id: 10, name: 'Canned Goods', image: 'https://tse3.mm.bing.net/th?id=OIP.wtEVYwEXGvBdoDoWPG9iGwHaHa&pid=Api&P=0&h=80' }

  ];

  const handleItemClick = (item) => {
    setSelectedItem(item);
  };

  const handleBuyClick = () => {
    handleBuyNow(selectedItem); // Pass the selected item to the parent component
    setSelectedItem(null); // Optionally reset the selected item
  };

  const handleCancelClick = () => {
    setSelectedItem(null);
  };

  return (
    <Container>
      <Row id="eye">
        <Col md={4} className="text-center">
          <img 
            src="https://rukminim2.flixcart.com/flap/80/80/image/29327f40e9c4d26b.png?q=100" 
            alt="Grocery" 
          />
          <p>
            <a 
              href="#grocery" 
              onClick={() => setSelectedCategory('grocery')}
            >
              Grocery
            </a>
          </p>
        </Col>
        <Col md={4} className="text-center">
          <img 
            src="https://tse3.mm.bing.net/th?id=OIP.RuIjOFtcUnU2VxlJDUW5HQAAAA&pid=Api&P=0&h=80" 
            alt="Electronics" 
          />
          <p><a href="#electronics" onClick={() => setSelectedCategory('electronics')}>Electronics</a></p>
        </Col>
        <Col md={4} className="text-center">
          <img 
            src="https://tse3.mm.bing.net/th?id=OIP.hWIs95f4BSWOzYoSzofiEAHaDj&pid=Api&P=0&h=80" 
            alt="Fashion" 
          />
          <p><a href="#fashion">Fashion</a></p>
        </Col>
      </Row>

      {selectedCategory === 'grocery' && !selectedItem && (
        <Row id="grocery" className="mt-4">
          {groceryItems.map(item => (
            <Col md={4} className="text-center" key={item.id}>
              <img 
                src={item.image} 
                alt={item.name} 
                className="img-fluid" 
                onClick={() => handleItemClick(item)} 
                style={{ cursor: 'pointer' }}
              />
              <p>{item.name}</p>
            </Col>
          ))}
        </Row>
      )}

      {selectedItem && (
        <Row className="mt-4 text-center">
          <Col md={12}>
            <h2>{selectedItem.name}</h2>
            <img src={selectedItem.image} alt={selectedItem.name} className="img-fluid" />
            <div className="mt-3">
              <Button variant="primary" onClick={handleBuyClick} className="me-2">
                Add To Cart
              </Button>
              <Button variant="secondary" onClick={handleCancelClick}>
                Cancel
              </Button>
            </div>
          </Col>
        </Row>
      )}

      <Row className="mt-4">
        <Carousel data-bs-theme="dark">
          <Carousel.Item>
            <img
              className="d-block w-100"
              src="https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/9384b37a848c5e60.jpg?q=20"
              alt="First slide"
            />
          </Carousel.Item>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src="https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/d9290fb51138d286.png?q=20"
              alt="Second slide"
            />
          </Carousel.Item>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src="https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/20a160ef30776af8.jpeg?q=20"
              alt="Third slide"
            />
          </Carousel.Item>
        </Carousel>
      </Row>

      <section id="about" className="mt-5">
        <h2>About Us</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam non urna nec quam tristique.</p>
      </section>

      <section id="services" className="mt-5">
        <h2>Our Services</h2>
        <p>We offer a wide range of services to meet your needs. From product sales to customer support.</p>
      </section>

      <section id="contact" className="mt-5">
        <h2>Contact Us</h2>
        <p>For any inquiries, please contact us at contact@example.com or call us at (123) 456-7890.</p>
      </section>

      <footer className="footer mt-5">
        <Container>
          <Row>
            <Col md={4} className="text-center">
              <h5>Contact Us</h5>
              <p>Email: flipcart@example.com</p>
              <p>Phone: +123 456 7890</p>
            </Col>
            <Col md={4} className="text-center">
              <h5>Follow Us</h5>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a><br />
            </Col>
            <Col md={4} className="text-center">
              <h5>Navigation</h5>
              <a href="#home">Home</a><br />
              <a href="#about">About</a><br />
              <a href="#services">Services</a><br />
              <a href="#contact">Contact</a>
            </Col>
          </Row>
          <Row className="mt-3">
            <Col className="text-center">
              <p>&copy; {new Date().getFullYear()} Your Company. All rights reserved.</p>
            </Col>
          </Row>
        </Container>
      </footer>
    </Container>
  );
}

export default HomePage;
