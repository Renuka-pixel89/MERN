import React from 'react';
import { useLocation } from 'react-router-dom';

function SearchResultsPage() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const query = searchParams.get('q');

  return (
    <div>
      <h1>Search Results for "{query}"</h1>
      {/* Display the results based on the query */}
    </div>
  );
}

export default SearchResultsPage;
