import image from './butterfly1.jfif';
import video from './WhatsApp Video 2024-08-05 at 10.24.13 AM.mp4'
import audio from './WhatsApp Audio 2024-08-06 at 2.54.45 AM.mpeg'
/*import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;*/


import React, {Component} from 'react';
class Fruits extends React.Component {
  render(){
    return (
      <div>
      <Apple/>
      <Banana/>
      <Pineapple/>
      <Grapes/>
      </div>
      );
  }
}
class Apple extends React.Component{
  render(){
    return (
    <div>
    <img src = {image} className="Fruits-image" alt="image"/>
    </div>
    );
  }
}
class Banana extends React.Component{
  render(){
    return (
    <div>
    <video src = {video} className="Fruits-video" alt="video" controls/>
    </div>
    );
  }
}
class Pineapple extends React.Component{
  render(){
    return(
      <div>
      <audio src = {audio} className="Fruits-audio" alt="audio" controls/>
      </div>
    );
  }
}
class Grapes extends React.Component{
  render(){
    return(
      <div className="form">
      <h2>Login Form</h2>
      <form>
      <label>Email:
      <input type="text"/>
      </label><br/>
      <label>Password:
      <input type="text"/>
      </label><br/>
      <button>Login</button>
      </form>
      </div>
    );
  }
}
export default Fruits;