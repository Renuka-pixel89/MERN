//import React from 'react';
//import ReactDOM from 'react-dom/client';
//import './index.css';
//import Fruits from './App';
//import reportWebVitals from './reportWebVitals';

/*const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();*/

/*
const myElement = <h1>React is {15+5} times better with JSX</h1>
const container=document.getElementById("root");
const renuka=ReactDOM.createRoot(container);
renuka.render(myElement);*/

/*const myElement = (
  <ul>
  <li>Apples</li>
  <li>Bananas</li>
  <li>Cherries</li>
  </ul>
  );

const renuka=ReactDOM.createRoot(document.getElementById('root'));
renuka.render(myElement);*/

/*const myElement = <h1 className="myclass">Welcome to SALEM city</h1>
const renuka=ReactDOM.createRoot(document.getElementById('root'));
renuka.render(myElement);*/

/*const x = 50;
const myElement = <h1 className="myclass">{(x) < 100 ? "Google" : "Yahoo"}</h1>
const renuka=ReactDOM.createRoot(document.getElementById('root'));
renuka.render(myElement);*/
/* const x = 50;
 let text="Google engine";
 if(x<100) {
  text="Yahoo engine";
 }

 const myElement = <h1 className="myclass">{text}</h1>
const renuka=ReactDOM.createRoot(document.getElementById('root'));
renuka.render(myElement);*/

/*function Mango() {
  return <h1>Welcome to mango citys!</h1>;
}
const renuka=ReactDOM.createRoot(document.getElementById('root'));
renuka.render(<Mango/>);*/

/*const myElement = (
  <table className="myclass">
  <tr id="r1">
  <th>Name</th>
  <th>Price</th>
  <th>Address</th>
  </tr>
  <tr>
  <td>Mango</td>
  <td>20</td>
  <td>Salem</td>
  </tr>
  <tr id="r1">
  <td>Pineapple</td>
  <td>30</td>
  <td>Ooty</td>
  </tr>
  </table>
  );*/
//const renuka=ReactDOM.createRoot(document.getElementById('root'));
//renuka.render(<Fruits/>);

/*import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
*/

import React,{useState} from 'react';
import './index.css';
import ReactDOM from 'react-dom/client';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, Nav,Container,Row,Col,Dropdown,Card,Button,Form,Carousel,Offcanvas} from 'react-bootstrap';
import image from './img1.jpg';
import img2 from './img2.png';
import img3 from './img3.png';
import img4 from './img4.png';
import p1 from './p1.jpg';
import p2 from './p2.jpg';
import p3 from './p3.jpg';

function App() {
  const [showLogin, setShowLogin] = useState(false);
  const [showReg, setShowReg] = useState(false);

  const handleCloseLogin = () => setShowLogin(false);
  const handleShowLogin = () => setShowLogin(true);

  const handleCloseReg = () => setShowReg(false);
  const handleShowReg = () => setShowReg(true);

  return (
    <>
      {/* Navigation Bar */}
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand href="#home">Renuka Website</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link href="#home">Home</Nav.Link>
              <Nav.Link href="#about">About</Nav.Link>
              <Nav.Link href="#services">Services</Nav.Link>
              <Nav.Link href="#portfolio">Portfolio</Nav.Link>
              <Nav.Link href="#contact">Contact</Nav.Link>
              <Nav.Link href="#footer">Footer</Nav.Link>
              <Dropdown>
      <Dropdown.Toggle variant="success" id="dropdown-basic">
        Dropdown Button
      </Dropdown.Toggle>

      <Dropdown.Menu>
        <Dropdown.Item onClick={handleShowLogin} href="#login">Login</Dropdown.Item>
        <Dropdown.Item onClick={handleShowReg} href="#registration">Registration</Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <Container id="home">
          <h1>Welcome to My Website</h1>
          <p>This is the home section of the website.</p>
        </Container>

      <Container className="my-4" id="about">
      <h1>About our Website</h1>
        <Row>
          <Col>
            <img src={image} id="myimage" className="img-fluid"/>
          </Col>
          <Col>
          <p>Paragraphs are the group of sentences combined together, about a certain topic. It is a very important form of writing as we write almost everything in paragraphs, be it an answer, essay, story, emails, etc.We can say that a well-structured paragraph is the essence of good writing. The purposes of the paragraph are to give information, to explain something, to tell a story, and to convince someone that our idea is right.We can say that a well-structured paragraph is the essence of good writing. The purposes of the paragraph are to give information, to explain something, to tell a story, and to convince someone that our idea is right.</p>
          </Col>
        </Row>
      </Container>


      <Container id="services">
      <h1>Our Services</h1>
          <Row>
            <Col md={4}>
              <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src={img2} />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the
          bulk of the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
            </Col>
            <Col md={4}>
              <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src={img3} />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the
          bulk of the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
            </Col>
            <Col md={4}>
              <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src={img4} />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the
          bulk of the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
            </Col>
          </Row>
        </Container>



      <Container id="portfolio">
          <h1>Our Portfolio</h1>
          <Row className="port">
            <Col md={6}>
              <Card className="mb-4">
                <Card.Img variant="top" src={p1} />
                <Card.Body>
                  <Card.Title>Project 1</Card.Title>
                  <Card.Text>Brief description of Project 1.</Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6}>
              <Card className="mb-4">
                <Card.Img variant="top" src={p2} />
                <Card.Body>
                  <Card.Title>Project 2</Card.Title>
                  <Card.Text>Brief description of Project 2.</Card.Text>
                </Card.Body>
              </Card>
            </Col>
            </Row>
            <Row>
            <Col md={4}>
              <Card className="mb-4">
                <Card.Img variant="top" src={p3} />
                <Card.Body>
                  <Card.Title>Project 3</Card.Title>
                  <Card.Text>Brief description of Project 3.</Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="mb-4">
                <Card.Img variant="top" src={p2} />
                <Card.Body>
                  <Card.Title>Project 4</Card.Title>
                  <Card.Text>Brief description of Project 3.</Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="mb-4">
                <Card.Img variant="top" src={p1} />
                <Card.Body>
                  <Card.Title>Project 5</Card.Title>
                  <Card.Text>Brief description of Project 3.</Card.Text>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>





        <Offcanvas show={showLogin} onHide={handleCloseLogin}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Login</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <Form>
            <Form.Group className="mb-3" controlId="formLoginEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control type="email" placeholder="Enter your email" />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formLoginPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="Enter your password" />
            </Form.Group>
            <Button variant="primary" type="submit">
              Login
            </Button>
          </Form>
        </Offcanvas.Body>
      </Offcanvas>

      {/* Offcanvas for Registration */}
      <Offcanvas show={showReg} onHide={handleCloseReg}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Registration</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <Form>
            <Form.Group className="mb-3" controlId="formRegName">
              <Form.Label>Name</Form.Label>
              <Form.Control type="text" placeholder="Enter your name" />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formRegEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control type="email" placeholder="Enter your email" />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formRegPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="Enter your password" />
            </Form.Group>
            <Button variant="primary" type="submit">
              Register
            </Button>
          </Form>
        </Offcanvas.Body>
      </Offcanvas>


        


        <Container id="contact">
          <h1>Contact Us</h1>
          <Form>
            <Form.Group className="mb-3" controlId="formName">
              <Form.Label>Name</Form.Label>
              <Form.Control type="text" placeholder="Enter your name" />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control type="email" placeholder="Enter your email" />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formMessage">
              <Form.Label>Message</Form.Label>
              <Form.Control as="textarea" rows={3} />
            </Form.Group>

            <Button variant="primary" type="submit">
              Submit
            </Button>
          </Form>
        </Container>


  <Container id="footer">
  <footer className="text-center text-white">
  <div className="container p-4">
    <section className="video">
      <div className="row d-flex justify-content-center">
        <div className="col-lg-6">
          <div className="ratio ratio-16x9">
            <iframe
              className="shadow-1-strong rounded"
              src="https://www.youtube.com/embed/vlDzYIIOYmM"
              title="YouTube video"
              allowfullscreen
            ></iframe>
          </div>
        </div>
      </div>
    </section>
    </div>
  </footer>
  </Container>


      <Container className="my-4">
      {/* Footer */}
      <footer className="bg-dark text-white text-center py-3">
        <Container>
          <p>@copy  2024 Renuka Website. All rights reserved.</p>
        </Container>
      </footer>
      </Container>
      </>
    
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);