import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import Image from 'react-bootstrap/Image';
import Row from 'react-bootstrap/Row';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import 'bootstrap/dist/css/bootstrap.css'; 

function Contact() {
  return (
<Container>
    <Row>
        <Col>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d103026.57058727425!2d80.4367346110257!3d16.33582377424001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a358b23d0f761c1%3A0x38b09fed35a46ce5!2sChalapathi%20Institute%20of%20Engineering%20and%20Technology!5e0!3m2!1sen!2sin!4v1723103013718!5m2!1sen!2sin"></iframe>  
        </Col>
     <Col >
      <Form>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email address</Form.Label>
        <Form.Control type="email" placeholder="Enter email" />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="Check me out" />
      </Form.Group>
      <Button variant="primary" type="submit">
        Submit
      </Button>
      </Form>
      </Col>
    </Row>
</Container>
  );
}
export default Contact;