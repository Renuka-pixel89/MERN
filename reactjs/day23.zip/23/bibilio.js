const express=require('express');
const mongoose=require('mongoose');
const cors=require('cors');
const app=express();
app.use(cors());
app.use(express.json());
mongoose.connect('mongodb://localhost:27017/biography',{

});
const infoSchema=new mongoose.Schema({
	cmid:{type:Number,required:true},
	cmname:{type:String,required:true},
	cmdob:{type:Date,required:true},
	mstatus:{type:Boolean, default:false,required:true},
	cmsalary:{type:Number,required:true},
	cmaddress:[
		{city:{type:String,required:true},
		pincode:{type:Number,required:true}}
		],
	cmemail:{type:String,required:true}
});
const Info=mongoose.model('CMInfo',infoSchema);
app.get('/info',async(req,res) => {
	const info=await Info.find();
	res.send(info);
});
app.get('/info/:id',async(req,res) => {
	const info=await Info.findOne();
	res.send(info);
});
app.post('/info',async(req,res) => {
	const info=new Info({
		cmid:req.body.cmid,
		cmname:req.body.cmname,
		cmdob:req.body.cmdob,
		mstatus:req.body.mstatus,
		cmsalary:req.body.cmsalary,
		cmaddress:req.body.cmaddress,
		cmemail:req.body.cmemail
	});
	await info.save();
	res.send(info);
});
app.put('/info/:id', async(req,res) => {
	const info=await Info.findByIdAndUpdate(req.params.id,req.body,{new:true});
	res.send(info);
});
app.delete('/info/:id',async(req,res) => {
	await Info.findByIdAndDelete(req.params.id);
	res.send({message:'Item deleted'});
});
app.listen(5000, () => {
	console.log('Server is running on port 5000');
});
